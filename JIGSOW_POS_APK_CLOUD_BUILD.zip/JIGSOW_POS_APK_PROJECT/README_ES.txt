JIGSOW POS - Proyecto Android basado en V59

Este proyecto envuelve JIGSOW POS V59 en un WebView Android con almacenamiento DOM/localStorage habilitado.

Para generar el APK: abrir el proyecto en Android Studio y ejecutar Build > Build APK(s).

Nota: este entorno no dispone del Android SDK/build tools, por lo que no se adjunta un APK compilado; se entrega el proyecto completo listo para compilar.
